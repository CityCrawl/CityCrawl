﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CC_Web.Utilities
{
    public class AppSettings
    {
        public string SecretKey { get; set; }
    }
}
