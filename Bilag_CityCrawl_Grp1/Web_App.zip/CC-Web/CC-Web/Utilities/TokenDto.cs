﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CC_Web.Utilities
{
    public class TokenDto
    {
        public string JWT { get; set; }
    }
}
