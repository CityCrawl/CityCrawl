﻿namespace CC_Web.Models.Data
{
    public class CreatePubcrawl
    {
        public string Email { get; set; }
        public Pubcrawl Pubcrawl { get; set; }
    }
}