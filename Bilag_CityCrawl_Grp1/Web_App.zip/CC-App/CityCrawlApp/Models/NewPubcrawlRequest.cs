﻿namespace CityCrawlApp.Models
{
    public class NewPubcrawlRequest
    {
        public string Email { get; set; }
        public Pubcrawl Pubcrawl { get; set; }
    }
}