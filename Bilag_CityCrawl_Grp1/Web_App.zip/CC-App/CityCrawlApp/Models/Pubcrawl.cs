﻿using System;

namespace CityCrawlApp.Models
{
    public class Pubcrawl
    {
        public string PakkeNavn { get; set; }
        public DateTime MoedeTid { get; set; }
        public string MoedeSted { get; set; }
    }
}