﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CityCrawlApp
{
    class Settings
    {
        public static string baseUrl = "https://localhost:44361/api"; // her indsættes den rigitge url til serveren
    }
}
