﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace CC_Web.Data.Migrations
{
    public partial class UpdateafModelsdata : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
